ReadMe for Brick Breaker

This simple Brick Breaker game is built following the  tutorial "2D breakout 
game using pure JavaScript" provided on MDN web docs.
-->https://developer.mozilla.org/en-US/docs/Games/Tutorials/2D_Breakout_game_pure_JavaScript